from flask import Flask, request, send_from_directory,send_file,render_template
import json

app=Flask(__name__, template_folder='templates', static_folder='static')

@app.route('/')
def home():
    return render_template("home.html")

@app.route('/result', methods = ['POST', 'GET'])
def result():
   if request.method == 'POST':
      result = { key: value[0] if len(value) == 1 else value
                for key, value in request.form.iterlists()
                }
      with open('file.json', 'w') as f:
          json.dump(request.form, f)
      return render_template('result.html')

@app.route('/file-download/')
def file_download():
    try:
        render_template('result.html')
    except Exception as e:
        return str(e)


@app.route('/return-files/', methods=['POST','GET'])
def return_files():
    try:
        #url = request.args['url']
        #filename = request.args.get('filename', 'file.json')
        #r = requests.get(url)
        #strIO = StringIO.StringIO(r.content)
        return send_file('file.json', attachment_filename='file.json',as_attachment=True)
    except Exception as e:
		return str(e)

if __name__ == "__main__":
    app.run(debug=True)


